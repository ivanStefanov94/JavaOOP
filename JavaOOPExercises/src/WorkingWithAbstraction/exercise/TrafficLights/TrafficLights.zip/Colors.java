package WorkingWithAbstraction.exercise.TrafficLights;

public enum Colors {
    RED,
    GREEN,
    YELLOW;
}
